#!/usr/bin/env python
import os
import sys

def mainloop():
	print('Testing...')


if __name__ == '__main__':
	mainloop()
